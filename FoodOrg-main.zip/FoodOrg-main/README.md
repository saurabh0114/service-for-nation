# FoodOrg

>Website for FoodOrg my project
>
>It will be a non profitable service/platform to connect food donaters and food requesters
>
